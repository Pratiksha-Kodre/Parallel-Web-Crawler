package com.udacity.webcrawler.main;

import com.google.inject.Guice;
import com.udacity.webcrawler.WebCrawler;
import com.udacity.webcrawler.WebCrawlerModule;
import com.udacity.webcrawler.json.ConfigurationLoader;
import com.udacity.webcrawler.json.CrawlResult;
import com.udacity.webcrawler.json.CrawlResultWriter;
import com.udacity.webcrawler.json.CrawlerConfiguration;
import com.udacity.webcrawler.profiler.Profiler;
import com.udacity.webcrawler.profiler.ProfilerModule;

import javax.inject.Inject;
import java.io.OutputStreamWriter;
import java.io.Writer;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Objects;

public final class WebCrawlerMain {

  private final CrawlerConfiguration config;

  @Inject
  private WebCrawler crawler;

  @Inject
  private Profiler profiler;

  private WebCrawlerMain(CrawlerConfiguration config) {
    this.config = Objects.requireNonNull(config);
  }

  private void run() throws Exception {
    // Inject dependencies
    Guice.createInjector(new WebCrawlerModule(config), new ProfilerModule()).injectMembers(this);

    // Run the web crawler
    CrawlResult result = crawler.crawl(config.getStartPages());

    // Write the crawl results
    CrawlResultWriter resultWriter = new CrawlResultWriter(result);
    String resultPath = config.getResultPath();
    if (resultPath != null && !resultPath.isEmpty()) {
      resultWriter.write(Path.of(resultPath));
    } else {
      try (Writer writer = new OutputStreamWriter(System.out)) {
        resultWriter.write(writer);
      }
    }

    // Write the profile results
    String profileOutputPath = config.getProfileOutputPath();
    if (profileOutputPath != null && !profileOutputPath.isEmpty()) {
      profiler.writeData(Path.of(profileOutputPath));
    } else {
      try (Writer writer = new OutputStreamWriter(System.out)) {
        profiler.writeData(writer);
      }
    }
  }

  public static void main(String[] args) throws Exception {
    if (args.length != 1) {
      System.out.println("Usage: WebCrawlerMain <config-file>");
      return;
    }

    // Load the configuration
    CrawlerConfiguration config = new ConfigurationLoader(Paths.get(args[0])).load();

    // Run the web crawler
    new WebCrawlerMain(config).run();
  }
}
