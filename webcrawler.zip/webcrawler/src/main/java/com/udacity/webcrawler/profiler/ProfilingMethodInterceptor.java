package com.udacity.webcrawler.profiler;

import java.lang.reflect.InvocationHandler;
import java.lang.reflect.Method;
import java.time.Clock;
import java.time.Instant;
import java.time.Duration;
import java.util.Objects;

/**
 * A method interceptor that checks whether {@link Method}s are annotated with the {@link Profiled}
 * annotation. If they are, the method interceptor records how long the method invocation took.
 */
final class ProfilingMethodInterceptor implements InvocationHandler {

  private final Clock clock;
  private final ProfilingState state;
  private final Object delegate;

  ProfilingMethodInterceptor(Clock clock, ProfilingState state, Object delegate) {
    this.clock = Objects.requireNonNull(clock);
    this.state = Objects.requireNonNull(state);
    this.delegate = Objects.requireNonNull(delegate);
  }

  @Override
  public Object invoke(Object proxy, Method method, Object[] args) throws Throwable {
    if (method.isAnnotationPresent(Profiled.class)) {
      Instant startTime = clock.instant();
      try {
        // Invoke the actual method on the delegate
        return method.invoke(delegate, args);
      } catch (Throwable t) {
        throw t.getCause() != null ? t.getCause() : t;  // Ensure correct exception propagation
      } finally {
        // Record execution time even if an exception occurs
        Instant endTime = clock.instant();
        state.record(delegate.getClass(), method, Duration.between(startTime, endTime));
      }
    } else {
      // If the method is not annotated, just invoke it normally
      return method.invoke(delegate, args);
    }
  }
}
