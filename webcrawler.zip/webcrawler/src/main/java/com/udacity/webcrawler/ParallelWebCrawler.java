package com.udacity.webcrawler;

import com.udacity.webcrawler.json.CrawlResult;
import com.udacity.webcrawler.parser.PageParser;
import com.udacity.webcrawler.parser.PageParserFactory;

import javax.inject.Inject;
import java.time.Clock;
import java.time.Duration;
import java.time.Instant;
import java.util.*;
import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.stream.Collectors;

/**
 * A concrete implementation of {@link WebCrawler} that runs multiple threads on a
 * {@link ForkJoinPool} to fetch and process multiple web pages in parallel.
 */
final class ParallelWebCrawler implements WebCrawler {
  private final Clock clock;
  private final Duration timeout;
  private final int maxDepth;
  private final int popularWordCount;
  private final ForkJoinPool pool;
  private final PageParserFactory parserFactory;

  private final Set<String> ignoredWords = new HashSet<>(Arrays.asList("is", "and"));
  private final Set<String> ignoredUrls = ConcurrentHashMap.newKeySet(); // Thread-safe ignored URLs set

  @Inject
  ParallelWebCrawler(
          Clock clock,
          PageParserFactory parserFactory,
          @Timeout Duration timeout,
          @MaxDepth int maxDepth,
          @PopularWordCount int popularWordCount,
          @TargetParallelism int threadCount) {
    this.clock = clock;
    this.parserFactory = parserFactory;
    this.timeout = timeout;
    this.maxDepth = maxDepth;
    this.popularWordCount = popularWordCount;
    this.pool = new ForkJoinPool(Math.min(threadCount, getMaxParallelism()));
  }

  @Override
  public CrawlResult crawl(List<String> startingUrls) {
    Instant deadline = clock.instant().plus(timeout);
    Set<String> visitedUrls = ConcurrentHashMap.newKeySet();
    Map<String, Integer> wordCounts = new ConcurrentHashMap<>();
    AtomicInteger urlCount = new AtomicInteger(0);

    System.out.println("Starting crawl with ignored URLs: " + ignoredUrls);

    pool.invoke(new CrawlTask(startingUrls, 0, deadline, visitedUrls, wordCounts, urlCount));

    List<Map.Entry<String, Integer>> sortedWordCounts = new ArrayList<>(wordCounts.entrySet());
    sortedWordCounts.sort((a, b) -> {
      int freqCompare = b.getValue().compareTo(a.getValue());
      if (freqCompare != 0) return freqCompare;
      int lengthCompare = Integer.compare(b.getKey().length(), a.getKey().length());
      if (lengthCompare != 0) return lengthCompare;
      return a.getKey().compareTo(b.getKey());
    });

    Map<String, Integer> finalWordCounts = sortedWordCounts.stream()
            .limit(popularWordCount)
            .collect(Collectors.toMap(Map.Entry::getKey, Map.Entry::getValue, (e1, e2) -> e1, LinkedHashMap::new));

    return new CrawlResult.Builder()
            .setWordCounts(finalWordCounts)
            .setUrlsVisited(urlCount.get())
            .build();
  }

  @Override
  public int getMaxParallelism() {
    return Runtime.getRuntime().availableProcessors();
  }

  private class CrawlTask extends RecursiveAction {
    private final List<String> urls;
    private final int depth;
    private final Instant deadline;
    private final Set<String> visitedUrls;
    private final Map<String, Integer> wordCounts;
    private final AtomicInteger urlCount;

    public CrawlTask(List<String> urls, int depth, Instant deadline,
                     Set<String> visitedUrls, Map<String, Integer> wordCounts,
                     AtomicInteger urlCount) {
      this.urls = urls;
      this.depth = depth;
      this.deadline = deadline;
      this.visitedUrls = visitedUrls;
      this.wordCounts = wordCounts;
      this.urlCount = urlCount;
    }

    @Override
    protected void compute() {
      if (depth >= maxDepth || Instant.now(clock).isAfter(deadline)) return;

      List<CrawlTask> subTasks = new ArrayList<>();

      for (String url : urls) {
        // Normalize URL before checking or storing
        String normalizedUrl = url.toLowerCase().trim();

        // Check if URL should be ignored (thread-safe)
        if (!visitedUrls.add(normalizedUrl)) {
          System.out.println("Skipping already visited URL: " + normalizedUrl);
          continue;
        }
        if (ignoredUrls.contains(normalizedUrl)) {
          System.out.println("Ignoring URL: " + normalizedUrl);
          continue;
        }

        urlCount.incrementAndGet();
        System.out.println("Visiting URL: " + normalizedUrl);

        try {
          PageParser.Result result = parserFactory.get(url).parse();

          result.getWordCounts().forEach((word, count) -> {
            String cleanWord = word.toLowerCase();
            if (!ignoredWords.contains(cleanWord)) {
              wordCounts.merge(cleanWord, count, Integer::sum);
            }
          });

          if (depth + 1 < maxDepth) {
            subTasks.add(new CrawlTask(result.getLinks(), depth + 1, deadline, visitedUrls, wordCounts, urlCount));
          }
        } catch (Exception e) {
          System.err.println("Error crawling " + normalizedUrl + ": " + e.getMessage());
        }
      }

      invokeAll(subTasks);
    }
  }

}